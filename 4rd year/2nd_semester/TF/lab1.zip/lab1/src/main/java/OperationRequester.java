import BankImplementations.Bank;
import BankImplementations.BankNaive;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class OperationRequester {

    private String address;
    private int port;
    private Map<String, Integer> made;
    private Map<String, Integer> answered;
    
    public static void main(String[] args) {

        int port = Integer.parseInt(args[2]);
        ScheduledExecutorService es = Executors.newScheduledThreadPool(1);
        NettyMessagingService ms = new NettyMessagingService("" + port, Address.from(port), new MessagingConfig());

        ms.registerHandler("balance", (address, content) -> {
           
        }, es);

        ms.registerHandler("movement", (address, content) -> {

        })
    }
}