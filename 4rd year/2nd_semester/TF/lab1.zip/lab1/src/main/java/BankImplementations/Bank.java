package BankImplementations;

public interface Bank {

    public double balance();

    public boolean movement(double amount);
}
