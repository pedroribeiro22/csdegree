// 1
match(n) return count(n) as count

// 2
match()-[r]->() return count(r) as count

