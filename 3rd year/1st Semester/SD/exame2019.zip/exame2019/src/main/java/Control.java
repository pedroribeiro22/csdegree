public interface Control {

    void entra_carro();

    void sai_carro();

    void entra_barco();

    void sai_barco();

}
